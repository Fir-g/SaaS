import DemandAggregator from "@/components/DemandAggregator/demandaggregator";

export default function DemandAggregatorPage() {
  return (
    <div>
      <DemandAggregator />
    </div>
  );
}
