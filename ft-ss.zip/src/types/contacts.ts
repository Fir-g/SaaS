export type BlacklistedContact = {
  id: number;
  group_id: string;
  phone_number: string;
  is_blacklisted: boolean;
};
