import { BlacklistedContact } from "@/types/contacts";
import { ApiService } from "@/services/api";

// Get the API URL from environment variables (similar to DemandAggregator)
const CONTACT_API = import.meta.env.VITE_CONTACT_API as string | undefined;

class ContactApiService extends ApiService {
  constructor() {
    super();
    if (!CONTACT_API) {
      throw new Error("VITE_CONTACT_API is not set");
    }
    // Override base URL like DemandAggregator does
    this.baseUrl = CONTACT_API as unknown as string;
  }

  // Always use direct base URL, do not proxy
  protected getApiUrl(endpoint: string): string {
    return `${CONTACT_API}${endpoint}`;
  }
}

const contactApi = new ContactApiService();

export const getBlacklistedContacts = async (token?: string | null): Promise<BlacklistedContact[]> => {
  try {
    return contactApi.get<BlacklistedContact[]>("/FT/blacklisted-numbers", {}, token, true);
  } catch (error) {
    console.error("Error in service:", error);
    throw new Error("Failed to fetch blacklisted contacts");
  }
};