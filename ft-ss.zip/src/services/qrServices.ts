import { ApiService } from "@/services/api";

// Get the API URL from environment variables
const QR_API = import.meta.env.VITE_QR_API as string | undefined;

class QRApiService extends ApiService {
  constructor() {
    super();
    if (!QR_API) {
      throw new Error("VITE_QR_API is not set");
    }
    // Override base URL like DemandAggregator does
    this.baseUrl = QR_API as unknown as string;
  }

  // Always use direct base URL, do not proxy
  protected getApiUrl(endpoint: string): string {
    return `${QR_API}${endpoint}`;
  }
}

const qrApi = new QRApiService();

export const getQrCode = async (token?: string | null) => {
  return qrApi.post("/api/create-instance", {
    tenantId: "FT",
  }, token, true);
};